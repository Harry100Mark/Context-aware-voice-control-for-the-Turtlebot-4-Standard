# Fehlerbehebung: AttributeError und Bildlogik

## ✅ Behobene Probleme

### 1. **AttributeError: 'is_study_mode' nicht gefunden**
- **Problem**: `is_study_mode` wurde verwendet, bevor es definiert wurde
- **Lösung**: Reihenfolge der Variablendefinition korrigiert
- **Vorher**: `self.waiting_for_participant_data = self.is_study_mode` kam vor `self.is_study_mode = ...`
- **Nachher**: `self.is_study_mode` wird zuerst definiert, dann verwendet

### 2. **Bildlogik korrigiert entsprechend Anforderung**
- **Anforderung**: Raumplan.png → Teilnehmer-Dialog → currentPosition.png
- **Implementierung**: Neue Logik in `update_image()` Methode

## 🔄 Neuer Bildwechsel-Ablauf

### Im Studienmodus (`chat --stu`):

```
1. Start: Raumplan.png wird angezeigt
   ├── Hauptfenster öffnet sich (1600x1000)
   ├── Raumplan.png wird geladen und angezeigt
   └── Chat-Eingabe ist deaktiviert

2. Teilnehmer-Dialog erscheint
   ├── Modal-Dialog im Vordergrund
   ├── Raumplan.png bleibt im Hintergrund sichtbar
   └── Eingabe von Alter, Geschlecht, Tech-Hintergrund

3. Nach Dialog-Schließung: currentPosition.png
   ├── waiting_for_participant_data = False
   ├── using_current_position = True
   ├── Sofortiger Bildwechsel zu currentPosition.png
   └── Runde 1 startet mit aktiviertem Chat
```

## 🔧 Technische Änderungen

### In `chat_view.py`:

1. **Variablen-Reihenfolge korrigiert**:
```python
# Zuerst definieren
self.is_study_mode = (chat_node.mode == 'stu')

# Dann verwenden
self.waiting_for_participant_data = self.is_study_mode
```

2. **Bildlogik in `update_image()` verbessert**:
```python
if self.is_study_mode:
    if self.waiting_for_participant_data:
        # Vor Dialog: Raumplan.png
        current_image_path = self.initial_image_path
    else:
        # Nach Dialog: currentPosition.png
        current_image_path = self.image_path
```

3. **Expliziter Bildwechsel nach Dialog**:
```python
def show_participant_dialog(self):
    # ... Dialog-Logik ...
    
    # Nach Dialog-Schließung
    self.waiting_for_participant_data = False
    self.using_current_position = True
    self.update_image()  # Sofortiger Wechsel
```

## ✅ Erwartetes Verhalten jetzt:

```bash
cd ~/ros2_ws
source install/setup.bash
ros2 run chat chat --stu
```

1. **Großes Fenster** öffnet sich mit **Raumplan.png**
2. **Teilnehmer-Dialog** erscheint im Vordergrund
3. Nach Eingabe wechselt das Bild zu **currentPosition.png**
4. **Runde 1** startet mit aktiviertem Chat

Der AttributeError ist behoben und die Bildlogik funktioniert jetzt wie gewünscht! 🎯