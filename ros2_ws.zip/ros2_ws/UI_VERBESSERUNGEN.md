# UI-Verbesserungen für Studienmodus

## Implementierte Änderungen

### 1. ✅ Hauptfenster vergrößert
- **Neue Größe**: 1600x1000 Pixel für Studienmodus (vorher 1400x900)
- **Zentrierung**: Fenster wird automatisch in der Bildschirmmitte positioniert
- **Bildbereich**: Vergrößert auf 1000x800 Pixel (vorher 900x700)

### 2. ✅ Teilnehmer-Dialog im Vordergrund
- **Modal-Verhalten**: Dialog blockiert Hauptfenster bis zur Eingabe
- **Vordergrund-Fokus**: Dialog erscheint automatisch im Vordergrund
- **Zentrierung**: Dialog wird in der Bildschirmmitte positioniert
- **Topmost-Attribut**: Temporär gesetzt, um sicherzustellen, dass Dialog sichtbar ist

### 3. ✅ Bildanzeige-Logik überarbeitet
- **Initial**: `Raumplan.png` wird beim Start angezeigt
- **Nach Teilnehmer-Eingabe**: Wechsel zu `currentPosition.png` mit Roboter
- **Flag-System**: `waiting_for_participant_data` steuert Bildwechsel
- **Deaktivierte Eingabe**: Chat-Eingabe ist bis zur Teilnehmer-Eingabe deaktiviert

## Ablauf im Studienmodus (`chat --stu`)

### 1. Fenster-Setup
```
🖼️ Großes Hauptfenster (1600x1000) öffnet sich
├── Linke Seite: Raumplan.png (1000x800)
├── Rechte Seite: Chat-Interface (deaktiviert)
└── Willkommensnachricht erscheint
```

### 2. Teilnehmer-Dialog
```
📋 Modal-Dialog erscheint im Vordergrund (400x300)
├── Alter eingeben
├── Geschlecht auswählen (männlich/weiblich)
├── Tech-Hintergrund auswählen (ja/nein)
└── "Studie starten" bestätigen
```

### 3. Studie startet
```
🤖 Nach Bestätigung der Teilnehmer-Daten:
├── Wechsel zu currentPosition.png mit Roboter
├── Chat-Eingabe wird aktiviert
├── Erste Runde startet automatisch
└── Zielbereich wird angezeigt
```

## Technische Details

### Geänderte Dateien:
- **`chat_view.py`**: 
  - Fenstergröße und -positionierung
  - Bildlogik für Raumplan.png → currentPosition.png
  - Eingabefelder-Aktivierung/Deaktivierung
  - Neue Methoden: `show_initial_study_interface()`, `show_participant_dialog()`

- **`participant_dialog.py`**:
  - Verbessertes Modal-Verhalten
  - Automatische Zentrierung
  - Vordergrund-Fokus mit topmost-Attribut

### Neue Features:
- `waiting_for_participant_data` Flag
- Automatische Dialog-Positionierung
- Verbesserte Fenster-Hierarchie
- Staging der Bildanzeige

## Verwendung

```bash
cd ~/ros2_ws
source install/setup.bash
ros2 run chat chat --stu
```

### Erwartetes Verhalten:
1. ✅ **Großes Hauptfenster** öffnet sich mit Raumplan.png
2. ✅ **Teilnehmer-Dialog** erscheint automatisch im Vordergrund
3. ✅ Nach Eingabe der Teilnehmerdaten wird zu currentPosition.png gewechselt
4. ✅ Chat-Interface wird aktiviert und Studie beginnt

Die Verbesserungen sorgen für eine bessere Benutzererfahrung und vermeiden, dass der Teilnehmer den Dialog suchen muss! 🎯