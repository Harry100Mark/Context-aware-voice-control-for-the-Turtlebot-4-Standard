# Studiendatenerfassung für Roboter-Navigation-Studie

## Implementierte Features

### 1. Teilnehmer-Datenerfassung
- **Dialog beim Start**: `chat --stu` öffnet Dialog für Teilnehmerdaten
- **Erfasste Daten**:
  - Alter (Eingabefeld)
  - Geschlecht (männlich/weiblich, Radiobuttons)
  - Technischer Hintergrund IT (ja/nein, Radiobuttons)

### 2. Automatische Datensammlung pro Runde
- **Anzahl Kommandos**: Zählung aller Befehle bis zum Ziel
- **Befehlskategorien**: Automatische Klassifizierung in:
  - Navigation (gehe, fahre, navigiere, links, rechts, etc.)
  - Orientierung (drehe, schaue, wende, grad, winkel, etc.)
  - Fragen (wo, was, wie, warum, ?, hilfe, etc.)
  - Stop-Befehle (stop, halt, pause, warte, etc.)
  - Bestätigungen (ja, nein, ok, gut, richtig, etc.)
  - Sonstige (andere)
- **Latenz-Messung**: Zeit zwischen Befehlsempfang und -ausführung

### 3. CSV-Export nach jeder Studie
- **Pro Teilnehmer**: `participant_YYYYMMDD_HHMMSS.csv`
  - Teilnehmerdaten (Alter, Geschlecht, Tech-Hintergrund)
  - Rundendaten (Befehle, Kategorien, Latenz)
  - Zusammenfassung (Durchschnittswerte)
- **Aggregiert**: `aggregated_results.csv`
  - Durchschnittswerte über alle Teilnehmer
  - Demografische Auswertung
  - Leistungsmetriken

### 4. Dateispeicherung
- **Verzeichnis**: `~/ros2_ws/study_data/`
- **Automatische Erstellung**: Verzeichnis wird bei Bedarf erstellt
- **Kumulative Auswertung**: Wird bei jedem Teilnehmer aktualisiert

## CSV-Struktur

### Teilnehmer-CSV:
```csv
Participant_Info
Age,25
Gender,male
Technical_Background,True
Start_Time,2025-09-16T14:30:00

Round,Commands_Count,Duration_Seconds,Navigation_Commands,Orientation_Commands,Question_Commands,Stop_Commands,Confirmation_Commands,Other_Commands,Average_Latency
1,5,45.2,3,1,1,0,0,0,2.1
2,4,38.7,2,1,0,1,0,0,1.8
...

Summary
Total_Commands,42
Average_Commands_Per_Round,4.2
Average_Latency,1.95
```

### Aggregierte CSV:
```csv
Study_Summary
Total_Participants,15
Generation_Date,2025-09-16T16:45:00

Average_Age,28.3
Male_Participants,8
Female_Participants,7
Technical_Background_Count,9

Performance_Metrics
Average_Commands_Per_Round,4.7
Average_Latency_Seconds,2.1

Command_Categories_Average
Average_Navigation_Commands,2.8
Average_Orientation_Commands,0.9
...
```

## Verwendung

### Studienmodus starten:
```bash
cd ~/ros2_ws
source install/setup.bash
ros2 run chat chat --stu
```

### Ablauf:
1. Teilnehmer-Dialog erscheint (Alter, Geschlecht, Tech-Hintergrund)
2. 10 Runden werden automatisch durchgeführt
3. Jeder Befehl wird kategorisiert und zeitgestempelt
4. Nach jeder Runde: Zielprüfung und Datensammlung
5. Nach Studie: Automatischer CSV-Export

### Datenauswertung:
- Einzelne Teilnehmer: `~/ros2_ws/study_data/participant_*.csv`
- Gesamtauswertung: `~/ros2_ws/study_data/aggregated_results.csv`
- Durchschnitte werden automatisch über alle Teilnehmer berechnet

## Technische Details

### Neue Dateien:
- `src/chat/chat/study_data_model.py`: Hauptlogik für Datenerfassung
- `src/chat/chat/participant_dialog.py`: GUI für Teilnehmerdaten

### Geänderte Dateien:
- `src/chat/chat/chat.py`: Integration der Studiendatenerfassung
- `src/chat/chat/chat_view.py`: GUI-Anpassungen für Studienmodus

### Features:
- **MVC-Pattern**: Saubere Trennung zwischen Datenmodell und GUI
- **Thread-sicher**: Zeitstempel-Erfassung in separaten Threads
- **Robust**: Fehlerbehandlung und Fallback-Mechanismen
- **Erweiterbar**: Einfache Anpassung von Kategorien und Metriken